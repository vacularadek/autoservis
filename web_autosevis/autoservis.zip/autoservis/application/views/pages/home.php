
<!doctype html>
<html lang="en">
<title>Úvodní stránka</title>
    <style>
      .navbar-marg
      {
        margin-bottom: 25px;
      }
      .uprostred
      {
        text-align: center;
      }
    </style>

    <body>
        <div class= "container">
        <br /><br /><br /> 
        <h1 class="uprostred">AUTOSERVIS </h1>
        <br /><br /><br /> 
        <p class="uprostred">Dobrý den, Vítejte na stránce autoservisu! Tahle stránka je určena pouze pro adminy.
         Pokud nemáte admin přístup, tak Vás bohužel musím zklamat.</p>
         <p class="uprostred">Pokud máte admin přístup, pokračujte příhlášením.</p>
    </body>
</html>