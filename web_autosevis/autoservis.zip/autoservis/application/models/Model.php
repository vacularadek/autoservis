<?php

class Model extends CI_model

{
    public function __construct() {
        parent::__construct();
    }


    function insert_data($data)  
    {  
         $this->db->insert("zamestnanci", $data);  
    }  
    public function vypis_zamestnanci()  
    {  
         $query = $this->db->query("SELECT * FROM zamestnanci ORDER BY id ASC");  
         return $query->result();  
    }  
    function delete_data($id){  
         $this->db->where("id", $id);  
         $this->db->delete("zamestnanci");   
    }  
    function fetch_single_data($id)  
    {  
         $this->db->where("id", $id);  
         $query = $this->db->get("zamestnanci");  
         return $query;   
    }  
    function update_data($data, $id)  
    {  
         $this->db->where("id", $id);  
         $this->db->update("zamestnanci", $data);  
    }  


    function update_data_zakaznici($data, $id)  
    {  
         $this->db->where("idmajitele", $id);  
         $this->db->update("majitele", $data);  
    }  
    public function vypis_zakaznici()  
    {   
         $query = $this->db->query("SELECT * FROM majitele ORDER BY idmajitele ASC");  
         return $query->result();  
    }  
    function insert_data_zakaznici($data)  
    {  
         $this->db->insert("majitele", $data);  
    }  
    function vypis_jeden_zakaznik($id)  
    {  
         $this->db->where("idmajitele", $id);  
         $query = $this->db->get("majitele");   
         return $query; 
    }  

     function delete_data_zakaznici($id)
     {  
          $this->db->where("idmajitele", $id);  
          $this->db->delete("majitele");  
     }  

     function opravy()
     {
          $query = $this->db->query(
          "SELECT opravy.datum, majitele.prijmeni AS prijmeni_majitel, automobily.registracni_znacka, automobily.vyrobce, nahradni_dily.nazev,
          zamestnanci.prijmeni AS prijmeni_zamestnanec, nahradni_dily.cena + opravy.prace_cena AS cena
          FROM opravy
          JOIN majitele ON majitele.idmajitele = opravy.majitele_idmajitele
          JOIN automobily ON automobily.idautomobily = opravy.automobily_idautomobily
          JOIN nahradni_dily ON nahradni_dily.iddilu = opravy.nahradni_dily_iddilu
          JOIN zamestnanci ON zamestnanci.id = opravy.zamestnanci_id
          ORDER BY opravy.datum asc;");
          return $query->result();  
     }




}

